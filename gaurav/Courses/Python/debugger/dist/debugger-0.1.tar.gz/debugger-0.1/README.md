# degugger

A package for debugging that prints variables, dictionaries, nested dictionaries, lists, nested lists, and tuples with various colors and proper formatting.

## Installation

```bash
pip install debugger
```
